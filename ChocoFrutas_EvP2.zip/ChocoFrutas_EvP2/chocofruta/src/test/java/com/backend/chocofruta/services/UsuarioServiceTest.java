package com.backend.chocofruta.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.backend.chocofruta.entities.Usuario;
import com.backend.chocofruta.repositories.UsuarioRepositories;

@SpringBootTest
public class UsuarioServiceTest {

    @Mock
    private UsuarioRepositories usuarioRepositories;

    @InjectMocks
    private UsuarioServiceImpl usuarioServiceImpl;

    private Usuario usuario;

    @BeforeEach
    public void inicio() {
        usuario = new Usuario(1L, "Juan Pérez", "juan@mail.com", "123456", "cliente", true, LocalDateTime.now());
    }

    @Test
    public void findByAllTest() {
        List<Usuario> lista = Arrays.asList(usuario);
        when(usuarioRepositories.findAll()).thenReturn(lista);
        List<Usuario> resultado = usuarioServiceImpl.listarTodas();
        assertEquals(1, resultado.size());
        verify(usuarioRepositories).findAll();
    }

    @Test
    public void findByIdTest() {
        when(usuarioRepositories.findById(1L)).thenReturn(Optional.of(usuario));
        Usuario resultado = usuarioServiceImpl.obtenerId(1L);
        assertNotNull(resultado);
        assertEquals("Juan Pérez", resultado.getNombre());
        verify(usuarioRepositories).findById(1L);
    }

    @Test
    public void saveTest() {
        when(usuarioRepositories.save(any(Usuario.class))).thenReturn(usuario);
        Usuario usuarioTest = usuarioServiceImpl.crear(usuario);
        assertNotNull(usuarioTest);
        assertEquals("Juan Pérez", usuarioTest.getNombre());
        verify(usuarioRepositories).save(any(Usuario.class));
    }

    @Test
    public void loginTest() {
        when(usuarioRepositories.findByEmail("juan@mail.com")).thenReturn(Optional.of(usuario));
        Usuario resultado = usuarioServiceImpl.login("juan@mail.com", "123456");
        assertNotNull(resultado);
        assertEquals("juan@mail.com", resultado.getEmail());
        verify(usuarioRepositories).findByEmail("juan@mail.com");
    }
}