package com.backend.chocofruta.controller;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.backend.chocofruta.entities.Usuario;
import com.backend.chocofruta.services.UsuarioServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
public class UsuarioRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private UsuarioServiceImpl usuarioService;

    private List<Usuario> usuariosLista;

    @BeforeEach
    public void init() {
        cargarDatos();
    }

    private void cargarDatos() {
        usuariosLista = new ArrayList<>();

        Usuario u1 = new Usuario();
        u1.setId(1L);
        u1.setNombre("Admin Principal");
        u1.setEmail("admin@chocofruta.cl");
        u1.setPassword("admin123");
        u1.setRol("super-admin");
        u1.setActivo(true);
        u1.setFechaCreacion(LocalDateTime.now());

        Usuario u2 = new Usuario();
        u2.setId(2L);
        u2.setNombre("Juan Pérez");
        u2.setEmail("juan@gmail.com");
        u2.setPassword("cliente123");
        u2.setRol("cliente");
        u2.setActivo(true);
        u2.setFechaCreacion(LocalDateTime.now());

        usuariosLista.add(u1);
        usuariosLista.add(u2);
    }

    @Test
    public void testListarUsuarios() throws Exception {
        when(usuarioService.listarTodas()).thenReturn(usuariosLista);

        mockMvc.perform(get("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testCrearUsuario() throws Exception {
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setNombre("María González");
        nuevoUsuario.setEmail("maria@gmail.com");
        nuevoUsuario.setPassword("maria123");
        nuevoUsuario.setRol("cliente");

        Usuario usuarioGuardado = new Usuario();
        usuarioGuardado.setId(3L);
        usuarioGuardado.setNombre(nuevoUsuario.getNombre());
        usuarioGuardado.setEmail(nuevoUsuario.getEmail());
        usuarioGuardado.setPassword(nuevoUsuario.getPassword());
        usuarioGuardado.setRol(nuevoUsuario.getRol());
        usuarioGuardado.setActivo(true);
        usuarioGuardado.setFechaCreacion(LocalDateTime.now());

        when(usuarioService.crear(any(Usuario.class))).thenReturn(usuarioGuardado);

        mockMvc.perform(post("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevoUsuario)))
                .andExpect(status().isOk());
    }

    @Test
    public void testObtenerUsuarioPorId() throws Exception {
        Usuario usuario = usuariosLista.get(0);
        
        when(usuarioService.obtenerId(1L)).thenReturn(usuario);

        mockMvc.perform(get("/api/usuarios/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}