package com.backend.chocofruta.services;

import com.backend.chocofruta.entities.Producto;
import java.util.List;

public interface ProductoService {
    Producto crear(Producto producto);
    Producto obtenerId(Long id);
    List<Producto> listarTodas();
    void eliminar(Long id);
    Producto actualizar(Long id, Producto productoActualizado);
    Producto desactivar(Long id);
    List<Producto> buscarPorNombre(String nombre);
    List<Producto> filtrarPorCategoria(Long categoriaId);
    List<Producto> obtenerStockBajo();
}