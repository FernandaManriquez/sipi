package com.backend.chocofruta.services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.backend.chocofruta.entities.Usuario;
import com.backend.chocofruta.repositories.UsuarioRepositories;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepositories usuarioRepositories;

    @Override
    public Usuario login(String email, String password) {
        System.out.println("========================================");
        System.out.println("🔍 LOGIN SERVICE - INICIO");
        System.out.println("📧 Email recibido: [" + email + "]");
        System.out.println("📧 Longitud email: " + email.length());
        System.out.println("🔑 Password recibido: [" + password + "]");
        System.out.println("🔑 Longitud password: " + password.length());
        System.out.println("========================================");
        
        // Buscar usuario
        Optional<Usuario> usuarioOpt = usuarioRepositories.findByEmail(email);
        
        if (!usuarioOpt.isPresent()) {
            System.err.println("❌ USUARIO NO ENCONTRADO con email: " + email);
            
            // Listar TODOS los emails en la BD
            System.out.println("📋 Emails disponibles en BD:");
            List<Usuario> todos = (List<Usuario>) usuarioRepositories.findAll();
            for (Usuario u : todos) {
                System.out.println("   - [" + u.getEmail() + "] (length: " + u.getEmail().length() + ")");
            }
            
            throw new RuntimeException("Credenciales inválidas");
        }
        
        Usuario usuario = usuarioOpt.get();
        
        System.out.println("✅ Usuario encontrado:");
        System.out.println("   ID: " + usuario.getId());
        System.out.println("   Nombre: " + usuario.getNombre());
        System.out.println("   Email BD: [" + usuario.getEmail() + "]");
        System.out.println("   Password BD: [" + usuario.getPassword() + "]");
        System.out.println("   Rol: " + usuario.getRol());
        System.out.println("   Activo: " + usuario.getActivo());
        
        // Comparar passwords
        System.out.println("🔐 Comparando passwords:");
        System.out.println("   Password ingresado: [" + password + "]");
        System.out.println("   Password en BD:     [" + usuario.getPassword() + "]");
        System.out.println("   ¿Son iguales? " + usuario.getPassword().equals(password));
        
        if (!usuario.getPassword().equals(password)) {
            System.err.println("❌ PASSWORD INCORRECTO");
            throw new RuntimeException("Credenciales inválidas");
        }
        
        if (!usuario.getActivo()) {
            System.err.println("❌ USUARIO INACTIVO");
            throw new RuntimeException("Usuario inactivo");
        }
        
        System.out.println("✅ LOGIN EXITOSO");
        System.out.println("========================================");
        return usuario;
    }

    @Override
    public Usuario crear(Usuario usuario) {
        if (usuarioRepositories.existsByEmail(usuario.getEmail())) {
            throw new RuntimeException("El email ya está registrado");
        }
        usuario.setFechaCreacion(LocalDateTime.now());
        usuario.setActivo(true);
        return usuarioRepositories.save(usuario);
    }

    @Override
    public Usuario obtenerId(Long id) {
        return usuarioRepositories.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }

    @Override
    public List<Usuario> listarTodas() {
        return (List<Usuario>) usuarioRepositories.findAll();
    }

    @Override
    public void eliminar(Long id) {
        if (!usuarioRepositories.existsById(id)) {
            throw new RuntimeException("Usuario no encontrado");
        }
        usuarioRepositories.deleteById(id);
    }

    @Override
    public Usuario actualizar(Long id, Usuario usuarioActualizado) {
        Usuario existente = obtenerId(id);
        existente.setNombre(usuarioActualizado.getNombre());
        existente.setEmail(usuarioActualizado.getEmail());
        
        if (usuarioActualizado.getPassword() != null && 
            !usuarioActualizado.getPassword().isEmpty()) {
            existente.setPassword(usuarioActualizado.getPassword());
        }
        
        existente.setRol(usuarioActualizado.getRol());
        return usuarioRepositories.save(existente);
    }

    @Override
    public Usuario desactivar(Long id) {
        Usuario usuario = obtenerId(id);
        usuario.setActivo(false);
        return usuarioRepositories.save(usuario);
    }
}