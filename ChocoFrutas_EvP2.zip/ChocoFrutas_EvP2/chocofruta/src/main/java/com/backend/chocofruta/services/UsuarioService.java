package com.backend.chocofruta.services;

import com.backend.chocofruta.entities.Usuario;
import java.util.List;

public interface UsuarioService {
    Usuario crear(Usuario usuario);
    Usuario obtenerId(Long id);
    List<Usuario> listarTodas();
    void eliminar(Long id);
    Usuario actualizar(Long id, Usuario usuarioActualizado);
    Usuario desactivar(Long id);
    Usuario login(String email, String password);
}