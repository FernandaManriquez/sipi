package com.backend.chocofruta.services;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.backend.chocofruta.entities.Producto;
import com.backend.chocofruta.repositories.ProductoRepositories;

@Service
public class ProductoServiceImpl implements ProductoService {

    @Autowired
    private ProductoRepositories productoRepositories;

    @Override
    public Producto crear(Producto producto) {
        producto.setFechaCreacion(LocalDateTime.now());
        producto.setActivo(true);
        Producto productoGuardado = productoRepositories.save(producto);
        System.out.println("✅ Producto creado: " + productoGuardado.getNombre());
        return productoGuardado;
    }

    @Override
    public Producto obtenerId(Long id) {
        System.out.println("🔍 Buscando producto con ID: " + id);
        Producto producto = productoRepositories.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        System.out.println("✅ Producto encontrado: " + producto.getNombre());
        return producto;
    }

    @Override
    public List<Producto> listarTodas() {
        System.out.println("========================================");
        System.out.println("📦 LISTANDO TODOS LOS PRODUCTOS");
        System.out.println("========================================");
        
        try {
            List<Producto> productos = productoRepositories.findAll();
            
            System.out.println("✅ Total de productos encontrados: " + productos.size());
            
            if (productos.isEmpty()) {
                System.err.println("⚠️ NO SE ENCONTRARON PRODUCTOS EN LA BASE DE DATOS");
                System.err.println("⚠️ Verifica que hayas ejecutado los INSERT en MySQL");
            } else {
                System.out.println("📋 Primeros 5 productos:");
                productos.stream().limit(5).forEach(p -> {
                    String categoriaNombre = (p.getCategoria() != null) 
                        ? p.getCategoria().getNombre() 
                        : "SIN CATEGORÍA";
                    System.out.println("  - ID: " + p.getId() + 
                                     " | Nombre: " + p.getNombre() + 
                                     " | Precio: $" + p.getPrecio() +
                                     " | Stock: " + p.getStock() +
                                     " | Categoría: " + categoriaNombre +
                                     " | Activo: " + p.getActivo());
                });
            }
            
            System.out.println("========================================");
            return productos;
            
        } catch (Exception e) {
            System.err.println("========================================");
            System.err.println("❌ ERROR AL LISTAR PRODUCTOS:");
            System.err.println("Mensaje: " + e.getMessage());
            e.printStackTrace();
            System.err.println("========================================");
            throw new RuntimeException("Error al listar productos: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(Long id) {
        if (!productoRepositories.existsById(id)) {
            System.err.println("❌ No se puede eliminar: Producto con ID " + id + " no encontrado");
            throw new RuntimeException("Producto no encontrado");
        }
        productoRepositories.deleteById(id);
        System.out.println("🗑️ Producto eliminado con ID: " + id);
    }

    @Override
    public Producto actualizar(Long id, Producto productoActualizado) {
        System.out.println("🔄 Actualizando producto con ID: " + id);
        
        Producto existente = obtenerId(id);
        existente.setNombre(productoActualizado.getNombre());
        existente.setDescripcion(productoActualizado.getDescripcion());
        existente.setPrecio(productoActualizado.getPrecio());
        existente.setStock(productoActualizado.getStock());
        
        if (productoActualizado.getImagen() != null && 
            !productoActualizado.getImagen().isEmpty()) {
            existente.setImagen(productoActualizado.getImagen());
        }
        
        if (productoActualizado.getCategoria() != null) {
            existente.setCategoria(productoActualizado.getCategoria());
        }
        
        Producto actualizado = productoRepositories.save(existente);
        System.out.println("✅ Producto actualizado: " + actualizado.getNombre());
        return actualizado;
    }

    @Override
    public Producto desactivar(Long id) {
        System.out.println("🔒 Desactivando producto con ID: " + id);
        Producto producto = obtenerId(id);
        producto.setActivo(false);
        Producto desactivado = productoRepositories.save(producto);
        System.out.println("✅ Producto desactivado: " + desactivado.getNombre());
        return desactivado;
    }

    @Override
    public List<Producto> buscarPorNombre(String nombre) {
        System.out.println("🔍 Buscando productos con nombre: " + nombre);
        List<Producto> productos = productoRepositories.findByNombreContainingIgnoreCase(nombre);
        System.out.println("✅ Encontrados: " + productos.size() + " productos");
        return productos;
    }

    @Override
    public List<Producto> filtrarPorCategoria(Long categoriaId) {
        System.out.println("🔍 Filtrando productos por categoría ID: " + categoriaId);
        List<Producto> productos = productoRepositories.findByCategoria_Id(categoriaId);
        System.out.println("✅ Encontrados: " + productos.size() + " productos");
        return productos;
    }

    @Override
    public List<Producto> obtenerStockBajo() {
        System.out.println("⚠️ Buscando productos con stock bajo (menos de 5 unidades)");
        List<Producto> productos = productoRepositories.findByStockLessThanAndActivoTrue(5);
        System.out.println("✅ Encontrados: " + productos.size() + " productos con stock bajo");
        return productos;
    }
}
