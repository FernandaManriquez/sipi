package com.backend.chocofruta.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.backend.chocofruta.models.LoginRequest;
import com.backend.chocofruta.entities.Usuario;
import com.backend.chocofruta.services.UsuarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

@Tag(name = "Autenticación", description = "API para autenticación de usuarios")
@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/auth")
public class AuthRestController {

    @Autowired
    private UsuarioService usuarioServices;

    @Operation(
        summary = "Login de usuario", 
        description = "Autentica un usuario con email y contraseña"
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200", 
            description = "Login exitoso",
            content = @Content(schema = @Schema(implementation = Usuario.class))
        ),
        @ApiResponse(responseCode = "401", description = "Credenciales inválidas"),
        @ApiResponse(responseCode = "403", description = "Usuario inactivo")
    })
    @PostMapping("/login")
    public ResponseEntity<Usuario> login(@RequestBody LoginRequest loginData) {
        System.out.println("🔐 LOGIN - Email: " + loginData.getEmail());
        
        try {
            Usuario usuario = usuarioServices.login(
                loginData.getEmail(), 
                loginData.getPassword()
            );
            
            System.out.println("✅ LOGIN EXITOSO - Usuario: " + usuario.getNombre() + " | Rol: " + usuario.getRol());
            return ResponseEntity.ok(usuario);
            
        } catch (RuntimeException e) {
            System.err.println("❌ LOGIN FALLIDO - Error: " + e.getMessage());
            return ResponseEntity.status(401).build();
        }
    }
}