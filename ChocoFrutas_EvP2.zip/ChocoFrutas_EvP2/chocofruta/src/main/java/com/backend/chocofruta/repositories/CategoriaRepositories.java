package com.backend.chocofruta.repositories;

import org.springframework.data.repository.CrudRepository;
import com.backend.chocofruta.entities.Categoria;

public interface CategoriaRepositories extends CrudRepository<Categoria, Long> {

}
