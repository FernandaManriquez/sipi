import { Navbar } from "../../componentes/Navbar/Navbar";
import { Productos } from "../../componentes/Productos/Productos";
import { Footer } from "../../componentes/Footer/Footer";

export function Inventario() {
    return (
        <>
            <div className="container">
                <Navbar />
                <Productos />
                <Footer />
            </div>
        </>
    );
}