import { useState } from 'react';
import { Navbar } from "../../componentes/Navbar/Navbar";
import { Footer } from "../../componentes/Footer/Footer";
import './Pago.css';

export function Pago() {
    const [numeroPedido, setNumeroPedido] = useState('');
    const [pedidoEncontrado, setPedidoEncontrado] = useState(null);
    const [mostrarInfo, setMostrarInfo] = useState(false);

    // Datos simulados de pedidos
    const pedidosSimulados = {
        'CF-2025-001': {
            numero: 'CF-2025-001',
            fecha: '2025-01-15',
            total: 25600,
            cliente: 'María González',
            metodo: 'Transferencia',
            direccion: 'Av. Libertador 1234, Santiago',
            estado: 3,
            fechaActualizacion: '2025-01-16 14:30'
        },
        'CF-2025-002': {
            numero: 'CF-2025-002',
            fecha: '2025-01-14',
            total: 18900,
            cliente: 'Carlos Rodríguez',
            metodo: 'Débito',
            direccion: 'Los Aromos 567, Providencia',
            estado: 5,
            fechaActualizacion: '2025-01-16 10:15'
        },
        'CF-2025-003': {
            numero: 'CF-2025-003',
            fecha: '2025-01-16',
            total: 12300,
            cliente: 'Ana Silva',
            metodo: 'Crédito',
            direccion: 'Santa Rosa 890, Las Condes',
            estado: 2,
            fechaActualizacion: '2025-01-16 16:45'
        }
    };

    const estadosTexto = {
        1: 'Tu pedido ha sido recibido y está siendo procesado',
        2: 'Estamos verificando tu pago. Esto puede tardar algunas horas',
        3: 'Tu pago ha sido confirmado. Comenzamos a preparar tu pedido',
        4: 'Estamos empacando cuidadosamente tus productos',
        5: 'Tu pedido está en camino. Recibirás un código de seguimiento pronto'
    };

    const buscarPedido = () => {
        const pedidoTrimmed = numeroPedido.trim().toUpperCase();
        
        if (!pedidoTrimmed) {
            alert('Por favor, ingresa un número de pedido válido');
            return;
        }

        const pedido = pedidosSimulados[pedidoTrimmed];
        
        if (!pedido) {
            alert('Pedido no encontrado. Verifica que el número sea correcto o contacta a soporte.');
            setPedidoEncontrado(null);
            setMostrarInfo(false);
            return;
        }

        setPedidoEncontrado(pedido);
        setMostrarInfo(true);
    };

    const actualizarEstado = () => {
        if (pedidoEncontrado) {
            alert('Estado actualizado correctamente');
        }
    };

    const contactarSoporte = () => {
        const numero = pedidoEncontrado?.numero || 'No disponible';
        alert(`Para soporte con el pedido ${numero}, contáctanos:\n\n📞 +56 9 1234 5678\n📧 soporte@chocofrutas.cl\n💬 WhatsApp: +56 9 1234 5678`);
    };

    const descargarComprobante = () => {
        if (pedidoEncontrado) {
            alert(`Comprobante del pedido ${pedidoEncontrado.numero} descargado correctamente`);
        }
    };

    const getClasePaso = (numeroPaso) => {
        if (!pedidoEncontrado) return 'paso pendiente';
        
        if (numeroPaso < pedidoEncontrado.estado) return 'paso completado';
        if (numeroPaso === pedidoEncontrado.estado) return 'paso activo';
        return 'paso pendiente';
    };

    const getIconoPaso = (numeroPaso) => {
        if (!pedidoEncontrado) return numeroPaso;
        
        if (numeroPaso < pedidoEncontrado.estado) return '✓';
        return numeroPaso;
    };

    return (
        <>
            <div className="container">
                <Navbar />

                <div className="pago-content">
                    <h1 className="pago-title">Seguimiento de Pago</h1>

                    <div className="buscar-pedido">
                        <h3>Buscar mi pedido</h3>
                        <div className="buscar-row">
                            <input
                                type="text"
                                value={numeroPedido}
                                onChange={(e) => setNumeroPedido(e.target.value)}
                                className="form-control"
                                placeholder="Ingrese el número de pedido (ej: CF-2025-001)"
                                onKeyPress={(e) => e.key === 'Enter' && buscarPedido()}
                            />
                            <button className="btn-buscar" onClick={buscarPedido}>
                                🔍 Buscar Pedido
                            </button>
                        </div>
                        <small className="help-text">
                            El número de pedido fue enviado a tu correo electrónico
                        </small>
                    </div>

                    {mostrarInfo && pedidoEncontrado && (
                        <>
                            <div className="info-pedido">
                                <h3>📋 Información del Pedido</h3>
                                <div className="info-grid">
                                    <div className="info-item">
                                        <strong>N° de Pedido:</strong>
                                        <span>{pedidoEncontrado.numero}</span>
                                    </div>
                                    <div className="info-item">
                                        <strong>Fecha:</strong>
                                        <span>{new Date(pedidoEncontrado.fecha).toLocaleDateString('es-CL')}</span>
                                    </div>
                                    <div className="info-item">
                                        <strong>Total:</strong>
                                        <span>${pedidoEncontrado.total.toLocaleString('es-CL')}</span>
                                    </div>
                                    <div className="info-item">
                                        <strong>Cliente:</strong>
                                        <span>{pedidoEncontrado.cliente}</span>
                                    </div>
                                    <div className="info-item">
                                        <strong>Método de Pago:</strong>
                                        <span>{pedidoEncontrado.metodo}</span>
                                    </div>
                                    <div className="info-item">
                                        <strong>Dirección:</strong>
                                        <span>{pedidoEncontrado.direccion}</span>
                                    </div>
                                </div>
                            </div>

                            <div className="progreso-pago">
                                <div className="progreso-titulo">📊 Estado del Proceso</div>
                                
                                <div className="pasos-progreso">
                                    <div className={getClasePaso(1)}>
                                        <div className="paso-icono">{getIconoPaso(1)}</div>
                                        <div className="paso-titulo">Pedido Recibido</div>
                                        <div className="paso-descripcion">
                                            Tu pedido ha sido registrado correctamente
                                        </div>
                                    </div>

                                    <div className={getClasePaso(2)}>
                                        <div className="paso-icono">{getIconoPaso(2)}</div>
                                        <div className="paso-titulo">Pago Procesando</div>
                                        <div className="paso-descripcion">
                                            Verificando el pago recibido
                                        </div>
                                    </div>

                                    <div className={getClasePaso(3)}>
                                        <div className="paso-icono">{getIconoPaso(3)}</div>
                                        <div className="paso-titulo">Pago Confirmado</div>
                                        <div className="paso-descripcion">
                                            El pago ha sido aprobado
                                        </div>
                                    </div>

                                    <div className={getClasePaso(4)}>
                                        <div className="paso-icono">{getIconoPaso(4)}</div>
                                        <div className="paso-titulo">Preparando</div>
                                        <div className="paso-descripcion">
                                            Empacando tu pedido
                                        </div>
                                    </div>

                                    <div className={getClasePaso(5)}>
                                        <div className="paso-icono">{getIconoPaso(5)}</div>
                                        <div className="paso-titulo">Enviado</div>
                                        <div className="paso-descripcion">
                                            En camino a tu dirección
                                        </div>
                                    </div>
                                </div>

                                <div className="detalles-estado">
                                    <div className="estado-actual">
                                        Estado actual: Paso {pedidoEncontrado.estado} de 5
                                    </div>
                                    <div className="fecha-actualizacion">
                                        Última actualización: {new Date(pedidoEncontrado.fechaActualizacion).toLocaleString('es-CL')}
                                    </div>
                                    <div className="mensaje-estado">
                                        {estadosTexto[pedidoEncontrado.estado]}
                                    </div>
                                </div>

                                <div className="acciones-pedido">
                                    <button className="btn-accion" onClick={actualizarEstado}>
                                        🔄 Actualizar Estado
                                    </button>
                                    <button className="btn-accion" onClick={contactarSoporte}>
                                        💬 Contactar Soporte
                                    </button>
                                    <button className="btn-accion" onClick={descargarComprobante}>
                                        📄 Descargar Comprobante
                                    </button>
                                </div>
                            </div>
                        </>
                    )}

                    <div className="alert-info">
                        <strong>💡 Tip:</strong> Guarda tu número de pedido en un lugar seguro. 
                        Te permitirá hacer seguimiento en cualquier momento.
                    </div>
                </div>

                <Footer />
            </div>
        </>
    );
}