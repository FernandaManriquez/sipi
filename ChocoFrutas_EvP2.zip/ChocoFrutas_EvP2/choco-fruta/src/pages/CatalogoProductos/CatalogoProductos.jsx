import { useState, useEffect } from 'react';
import { Navbar } from "../../componentes/Navbar/Navbar";
import { Footer } from "../../componentes/Footer/Footer";
import './CatalogoProductos.css';

const API_BASE_URL = 'http://localhost:8080/api';

export function CatalogoProductos() {
    const [productos, setProductos] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        cargarProductos();
    }, []);

    const cargarProductos = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/productos`);
            const data = await response.json();
            const productosActivos = data.filter(p => p.activo);
            setProductos(productosActivos);
        } catch (error) {
            console.error('Error al cargar productos:', error);
        } finally {
            setLoading(false);
        }
    };

    const verDetalle = (id) => {
        window.location.href = `/detalle-producto/${id}`;
    };

    if (loading) {
        return (
            <div className="container">
                <Navbar />
                <div className="text-center mt-5">
                    <div className="spinner-border text-primary" role="status">
                        <span className="visually-hidden">Cargando...</span>
                    </div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <>
            <div className="container">
                <Navbar />

                <div className="catalogo-content">
                    <h3 className="catalogo-title">Lista de Productos - Choco&Frutas</h3>

                    <div className="table-responsive">
                        <table className="table table-striped catalogo-table">
                            <thead className="table-dark">
                                <tr>
                                    <th>Nombre</th>
                                    <th>Imagen</th>
                                    <th>Precio</th>
                                    <th>Descripción</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                {productos.map(prod => (
                                    <tr key={prod.id} className="producto-row">
                                        <td>
                                            <span className="producto-nombre">{prod.nombre}</span>
                                            {prod.stock < 5 && (
                                                <span className="badge bg-warning ms-2">
                                                    ⚠️ Stock Bajo
                                                </span>
                                            )}
                                        </td>
                                        <td>
                                            <img 
                                                src={`/img/${prod.imagen}`} 
                                                alt={prod.nombre} 
                                                className="producto-foto"
                                            />
                                        </td>
                                        <td>
                                            <span className="producto-precio">
                                                ${prod.precio.toLocaleString('es-CL')}
                                            </span>
                                        </td>
                                        <td>
                                            <span className="producto-descripcion">
                                                {prod.descripcion}
                                            </span>
                                        </td>
                                        <td>
                                            <button 
                                                className="btn-detalle"
                                                onClick={() => verDetalle(prod.id)}
                                            >
                                                Ver Detalle
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                <Footer />
            </div>
        </>
    );
}