import { useState, useEffect } from 'react';
import { Navbar } from "../../componentes/Navbar/Navbar";
import { Footer } from "../../componentes/Footer/Footer";
import './Carrito.css';

export function Carrito() {
    const [productosEnCarrito, setProductosEnCarrito] = useState([]);

    useEffect(() => {
        cargarCarrito();
    }, []);

    const cargarCarrito = () => {
        const carrito = JSON.parse(localStorage.getItem("carrito") || "[]");
        setProductosEnCarrito(carrito);
    };

    const actualizarCantidad = (index, accion) => {
        const nuevoCarrito = [...productosEnCarrito];

        if (accion === 'mas') {
            nuevoCarrito[index].cantidad++;
            nuevoCarrito[index].subtotal = nuevoCarrito[index].precio * nuevoCarrito[index].cantidad;
        } else if (accion === 'menos') {
            if (nuevoCarrito[index].cantidad > 1) {
                nuevoCarrito[index].cantidad--;
                nuevoCarrito[index].subtotal = nuevoCarrito[index].precio * nuevoCarrito[index].cantidad;
            } else {
                nuevoCarrito.splice(index, 1);
            }
        } else if (accion === 'eliminar') {
            nuevoCarrito.splice(index, 1);
        }

        localStorage.setItem("carrito", JSON.stringify(nuevoCarrito));
        setProductosEnCarrito(nuevoCarrito);
    };

    const calcularTotal = () => {
        return productosEnCarrito.reduce((sum, p) => sum + p.subtotal, 0);
    };

    const procederPago = () => {
        if (productosEnCarrito.length === 0) {
            alert("⚠️ Tu carrito está vacío. Agrega productos antes de proceder al pago.");
            return;
        }
        alert("✅ Redirigiendo al proceso de pago...");
        window.location.href = "/pago";
    };

    return (
        <>
            <div className="container">
                <Navbar />

                <div className="carrito-content">
                    <h1 className="carrito-title">Tu Carrito de Compras</h1>

                    {productosEnCarrito.length === 0 ? (
                        <div className="carrito-vacio">
                            <h3>Tu carrito está vacío</h3>
                            <p>Agrega algunos deliciosos chocolates y frutas para comenzar tu compra.</p>
                            <a href="/catalogo" className="btn-seguir-comprando">Ver Productos</a>
                        </div>
                    ) : (
                        <div className="carrito-lleno">
                            <table className="table table-striped carrito-table">
                                <thead className="table-dark">
                                    <tr>
                                        <th>Producto</th>
                                        <th>Precio</th>
                                        <th>Cantidad</th>
                                        <th>Subtotal</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {productosEnCarrito.map((producto, index) => (
                                        <tr key={index}>
                                            <td><strong>{producto.nombre}</strong></td>
                                            <td className="precio-cell">
                                                ${producto.precio.toLocaleString('es-CL')}
                                            </td>
                                            <td>
                                                <div className="cantidad-controles">
                                                    <button
                                                        className="btn-cantidad"
                                                        onClick={() => actualizarCantidad(index, 'menos')}
                                                    >
                                                        -
                                                    </button>
                                                    <span className="cantidad-display">
                                                        {producto.cantidad}
                                                    </span>
                                                    <button
                                                        className="btn-cantidad"
                                                        onClick={() => actualizarCantidad(index, 'mas')}
                                                    >
                                                        +
                                                    </button>
                                                </div>
                                            </td>
                                            <td className="precio-cell">
                                                ${producto.subtotal.toLocaleString('es-CL')}
                                            </td>
                                            <td>
                                                <button
                                                    className="btn-eliminar"
                                                    onClick={() => actualizarCantidad(index, 'eliminar')}
                                                >
                                                    Eliminar
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>

                            <div className="total-section">
                                <h3>Total: ${calcularTotal().toLocaleString('es-CL')}</h3>
                            </div>

                            <div className="acciones-carrito">
                                <a href="/catalogo" className="btn-seguir-comprando">
                                    Seguir Comprando
                                </a>
                                <button className="btn-pagar" onClick={procederPago}>
                                    Proceder al Pago
                                </button>
                            </div>
                        </div>
                    )}
                </div>

                <Footer />
            </div>
        </>
    );
}