const ROLES = {
    SUPER_ADMIN: "super-admin",
    VENDEDOR: "vendedor",
    CLIENTE: "cliente"
};

export const guardarUsuario = (usuario) => {
    console.log('💾 Guardando usuario:', usuario);
    localStorage.setItem('usuarioLogueado', JSON.stringify(usuario));
};

export const obtenerUsuario = () => {
    const usuario = localStorage.getItem('usuarioLogueado');
    return usuario ? JSON.parse(usuario) : null;
};

export const estaLogueado = () => {
    return localStorage.getItem('usuarioLogueado') !== null;
};

export const cerrarSesion = () => {
    console.log('👋 Cerrando sesión...');
    localStorage.removeItem('usuarioLogueado');
};

export const esAdmin = () => {
    const usuario = obtenerUsuario();
    console.log('🔍 Verificando rol admin:', usuario?.rol);

    return usuario && (
        usuario.rol === ROLES.SUPER_ADMIN || 
        usuario.rol === ROLES.VENDEDOR
    );
};

export const tieneRol = (rol) => {
    const usuario = obtenerUsuario();
    return usuario && usuario.rol === rol;
};

export const debugSession = () => {
    const usuario = obtenerUsuario();
    console.group('🔍 DEBUG SESSION');
    console.log('Usuario:', usuario);
    console.log('Está logueado:', estaLogueado());
    console.log('Es admin:', esAdmin());
    console.groupEnd();
};