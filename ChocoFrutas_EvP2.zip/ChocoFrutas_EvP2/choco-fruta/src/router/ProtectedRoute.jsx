import { Navigate } from 'react-router-dom';

export function ProtectedRoute({ children }) {
    const usuarioLogueado = localStorage.getItem('usuarioLogueado');
    
    if (!usuarioLogueado) {
        return <Navigate to="/login" replace />;
    }
    
    return children;
}