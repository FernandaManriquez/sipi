import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Home } from './pages/Home/Home';
import { Blog } from './pages/Blog/Blog'; 
import { Contacto } from './pages/Contacto/Contacto';
import { Inventario } from './pages/Inventario/Inventario';
import { CatalogoProductos } from './pages/CatalogoProductos/CatalogoProductos';
import { DetalleProducto } from './pages/DetalleProducto/DetalleProducto';
import { Carrito } from './pages/Carrito/Carrito';
import { Registro } from './pages/Registro/Registro';
import { Pago } from './pages/Pago/Pago';
import { Login } from './componentes/Login/Login';
import { Dashboard } from './componentes/Dashboard/Dashboard';
import { CrearProducto } from './componentes/CrearProd/CrearProducto';
import { EditarProducto } from './componentes/EditarProd/EditarProd';
import { Productos } from './componentes/Productos/Productos';
import { Usuarios } from './componentes/Usuarios/Usuarios';
import { CrearUsuario } from './componentes/CrearUsuario/CrearUsuario';
import { EditarUsuario } from './componentes/EditarUsuario/EditarUsuario';
import { ProtectedRoute } from './router/ProtectedRoute';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        {/* Rutas públicas */}
        <Route path="/" element={<Home />} />
        <Route path="/blog" element={<Blog />} /> 
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/inventario" element={<Inventario />} />
        <Route path="/catalogo" element={<CatalogoProductos />} />
        <Route path="/detalle-producto/:id" element={<DetalleProducto />} />
        <Route path="/carrito" element={<Carrito />} />
        <Route path="/registro" element={<Registro />} />
        <Route path="/pago" element={<Pago />} />
        <Route path="/login" element={<Login />} />

        {/* Rutas protegidas - Solo para usuarios autenticados */}
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } 
        />

        <Route 
          path="/productos" 
          element={
            <ProtectedRoute>
              <Productos />
            </ProtectedRoute>
          } 
        />

        <Route 
          path="/crear-producto" 
          element={
            <ProtectedRoute>
              <CrearProducto />
            </ProtectedRoute>
          } 
        />

        <Route 
          path="/editar-producto/:id" 
          element={
            <ProtectedRoute>
              <EditarProducto />
            </ProtectedRoute>
          } 
        />

        <Route 
          path="/usuarios" 
          element={
            <ProtectedRoute>
              <Usuarios />
            </ProtectedRoute>
          } 
        />

        <Route 
          path="/crear-usuario" 
          element={
            <ProtectedRoute>
              <CrearUsuario />
            </ProtectedRoute>
          } 
        />

        <Route 
          path="/editar-usuario/:id" 
          element={
            <ProtectedRoute>
              <EditarUsuario />
            </ProtectedRoute>
          } 
        />

        {/* Ruta por defecto - Redirige al home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;