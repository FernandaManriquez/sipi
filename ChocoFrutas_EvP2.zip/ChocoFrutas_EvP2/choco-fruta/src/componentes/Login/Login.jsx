import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { guardarUsuario } from '../../utils/session';
import './Login.css';

const API_BASE_URL = 'http://localhost:8080/api';

export function Login() {
    const navigate = useNavigate();

    const [credenciales, setCredenciales] = useState({
        email: '',
        password: ''
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setCredenciales(prev => ({
            ...prev,
            [name]: value
        }));
        setError(null);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        setLoading(true);

        try {
            console.log('=== INICIO LOGIN ===');
            console.log('Email:', credenciales.email);
            
            const loginData = {
                email: credenciales.email,
                password: credenciales.password
            };

            console.log('JSON enviado:', JSON.stringify(loginData));

            const response = await fetch(`${API_BASE_URL}/auth/login`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(loginData)
            });

            console.log('Status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Error:', errorText);
                throw new Error('Credenciales incorrectas');
            }

            const usuario = await response.json();
            console.log('✅ Usuario recibido:', usuario);
            console.log('✅ Rol:', usuario.rol);
            
            guardarUsuario(usuario);

     
            if (usuario.rol === 'super-admin' || usuario.rol === 'vendedor') {
                navigate('/dashboard');
            } else {
                navigate('/');
            }

        } catch (err) {
            console.error('Error capturado:', err);
            setError(err.message || 'Error al iniciar sesión');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-container">
            <div className="login-card">
                <div className="login-header">
                    <img 
                        src="/img/Logo.png" 
                        alt="Choco&Frutas" 
                        className="login-logo"
                    />
                    <h2>Choco&Frutas</h2>
                    <p>Iniciar Sesión</p>
                </div>

                {error && (
                    <div className="alert alert-danger">
                        <i className="bi bi-exclamation-triangle"></i> {error}
                        <button onClick={() => setError(null)} className="error-close">×</button>
                    </div>
                )}

                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="email">
                            <i className="bi bi-envelope"></i> Email
                        </label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={credenciales.email}
                            onChange={handleChange}
                            disabled={loading}
                            placeholder="correo@ejemplo.com"
                            required
                            autoComplete="email"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">
                            <i className="bi bi-lock"></i> Contraseña
                        </label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value={credenciales.password}
                            onChange={handleChange}
                            disabled={loading}
                            placeholder="••••••••"
                            required
                            autoComplete="current-password"
                        />
                    </div>

                    <button 
                        type="submit" 
                        disabled={loading} 
                        className="btn-login"
                    >
                        {loading ? (
                            <>
                                <span className="spinner-border spinner-border-sm me-2"></span>
                                Iniciando sesión...
                            </>
                        ) : (
                            <>
                                <i className="bi bi-box-arrow-in-right"></i> Iniciar Sesión
                            </>
                        )}
                    </button>
                </form>

                <div className="login-footer">
                    <p className="registro-text">
                        ¿No tienes cuenta? 
                        <Link to="/registro" className="registro-link">
                            Regístrate aquí
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    );
}
