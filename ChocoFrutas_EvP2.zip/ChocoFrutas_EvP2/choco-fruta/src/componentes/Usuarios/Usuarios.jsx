import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './Usuarios.css';

export function Usuarios() {

    const [usuarios, setUsuarios] = useState([]);
    const [busqueda, setBusqueda] = useState('');

    const cargarUsuarios = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/usuarios');
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }

            const data = await response.json();
            console.log("Respuesta del backend:", data);

            const usuariosNormalizados = data.map(u => ({
                ...u,
                activo: u.activo === true || u.activo === 'true',
            }));

            setUsuarios(usuariosNormalizados);
        } catch (error) {
            console.error('Error al obtener los usuarios:', error);
        }
    };

    useEffect(() => {
        cargarUsuarios();
    }, []);

    const handleDesactivar = (id, nombre) => {
        if (window.confirm(`¿Estás seguro de desactivar el usuario "${nombre}"?`)) {
            fetch(`http://localhost:8080/api/usuarios/${id}/desactivar`, {
                method: 'PATCH'
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error al desactivar el usuario');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Usuario desactivado:', data);
                    alert('Usuario desactivado exitosamente');
                    cargarUsuarios();
                })
                .catch(error => {
                    console.error('Error al desactivar:', error);
                    alert('Error al desactivar el usuario');
                });
        }
    };

    // Filtrado de usuarios
    const usuariosFiltrados = usuarios.filter(u =>
        u.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
        u.email.toLowerCase().includes(busqueda.toLowerCase())
    );

    return (
        <div className="mi-tabla">
            <h3>Gestión de Usuarios</h3>

            {/* Barra de búsqueda */}
            <div className="row mb-3">
                <div className="col-md-8">
                    <div className="input-group">
                        <span className="input-group-text">
                            <i className="bi bi-search"></i>
                        </span>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Buscar por nombre o email..."
                            value={busqueda}
                            onChange={(e) => setBusqueda(e.target.value)}
                        />
                    </div>
                </div>
                <div className="col-md-4 text-end">
                    <Link className="btn btn-outline-dark" to="/crear-usuario">
                        <i className="bi bi-person-plus"></i> Crear Usuario
                    </Link>
                </div>
            </div>

            <div className="row">
                <div className="col-md-12">
                    <table className="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Estado</th>
                                <th>Fecha Creación</th>
                                <th>Editar</th>
                                <th>Desactivar</th>
                            </tr>
                        </thead>
                        <tbody>
                            {usuariosFiltrados.length === 0 ? (
                                <tr>
                                    <td colSpan="8" className="text-center">
                                        No se encontraron usuarios
                                    </td>
                                </tr>
                            ) : (
                                usuariosFiltrados.map((user) => (
                                    <tr key={user.id}
                                        style={{
                                            opacity: user.activo ? 1 : 0.5,
                                            backgroundColor: user.activo ? 'white' : '#f8f8f8'
                                        }}>
                                        <td>{user.id}</td>
                                        <td><strong>{user.nombre}</strong></td>
                                        <td>{user.email}</td>
                                        <td>
                                            <span className={`badge ${user.rol === 'super-admin' ? 'bg-danger' :
                                                    user.rol === 'vendedor' ? 'bg-info' : 'bg-secondary'
                                                }`}>
                                                {user.rol}
                                            </span>
                                        </td>
                                        <td>
                                            {user.activo ? (
                                                <span className="badge bg-success">Activo</span>
                                            ) : (
                                                <span className="badge bg-secondary">Inactivo</span>
                                            )}
                                        </td>
                                        <td>{new Date(user.fechaCreacion).toLocaleDateString('es-CL')}</td>
                                        <td>
                                            {user.activo ? (
                                                <Link className="btn btn-sm btn-outline-primary"
                                                    to={`/editar-usuario/${user.id}`}>
                                                    <i className="bi bi-pencil"></i> Editar
                                                </Link>
                                            ) : (
                                                <button className="btn btn-sm btn-outline-secondary"
                                                    style={{
                                                        cursor: 'not-allowed',
                                                        pointerEvents: 'none',
                                                    }}
                                                    disabled>
                                                    <i className="bi bi-pencil"></i> Editar
                                                </button>
                                            )}
                                        </td>
                                        <td>
                                            {user.activo ? (
                                                <button
                                                    className="btn btn-sm btn-outline-danger"
                                                    onClick={() => handleDesactivar(user.id, user.nombre)}>
                                                    <i className="bi bi-trash"></i> Desactivar
                                                </button>
                                            ) : (
                                                <button
                                                    className="btn btn-sm btn-secondary"
                                                    disabled>
                                                    Desactivado
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}