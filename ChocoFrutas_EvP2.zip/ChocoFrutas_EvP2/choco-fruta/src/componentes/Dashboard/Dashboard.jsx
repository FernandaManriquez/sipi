import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Navbar } from '../../componentes/Navbar/Navbar';
import { Footer } from '../../componentes/Footer/Footer';
import './Dashboard.css';

const API_BASE_URL = 'http://localhost:8080/api';

export function Dashboard() {
    const [estadisticas, setEstadisticas] = useState({
        totalProductos: 0,
        totalUsuarios: 0,
        productosStockBajo: 0
    });
    
    const [productosAlerta, setProductosAlerta] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        cargarEstadisticas();
    }, []);

    const cargarEstadisticas = async () => {
        try {
            setLoading(true);

            const respProductos = await fetch(`${API_BASE_URL}/productos`);
            const productos = await respProductos.json();

            const respUsuarios = await fetch(`${API_BASE_URL}/usuarios`);
            const usuarios = await respUsuarios.json();

            const productosStockBajo = productos.filter(p => p.stock < 5 && p.activo);

            setEstadisticas({
                totalProductos: productos.length,
                totalUsuarios: usuarios.length,
                productosStockBajo: productosStockBajo.length
            });

            setProductosAlerta(productosStockBajo);

        } catch (error) {
            console.error('Error al cargar estadísticas:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <>
                <div className="container">
                    <Navbar />
                    <div className="text-center mt-5">
                        <div className="spinner-border text-primary" role="status">
                            <span className="visually-hidden">Cargando...</span>
                        </div>
                    </div>
                </div>
            </>
        );
    }

    return (
        <>
            <div className="container">
                <Navbar />

                <div className="dashboard-content">
                    <h2 className="dashboard-title">Dashboard Administrativo</h2>

                    <div className="row">
                        <div className="col-md-4 mb-3">
                            <div className="stat-card">
                                <div className="stat-icon">
                                    <i className="bi bi-box-seam"></i>
                                </div>
                                <div className="stat-info">
                                    <h3>{estadisticas.totalProductos}</h3>
                                    <p>Total de Productos</p>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-4 mb-3">
                            <div className="stat-card">
                                <div className="stat-icon">
                                    <i className="bi bi-people"></i>
                                </div>
                                <div className="stat-info">
                                    <h3>{estadisticas.totalUsuarios}</h3>
                                    <p>Total de Usuarios</p>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-4 mb-3">
                            <div className="stat-card alert-card">
                                <div className="stat-icon">
                                    <i className="bi bi-exclamation-triangle"></i>
                                </div>
                                <div className="stat-info">
                                    <h3>{estadisticas.productosStockBajo}</h3>
                                    <p>Productos Stock Bajo</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {productosAlerta.length > 0 && (
                        <div className="stock-alerts">
                            <h3>⚠️ Alertas de Stock Crítico</h3>
                            <div className="table-responsive">
                                <table className="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Producto</th>
                                            <th>Stock Actual</th>
                                            <th>Categoría</th>
                                            <th>Precio</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {productosAlerta.map(prod => (
                                            <tr key={prod.id}>
                                                <td>
                                                    <strong>{prod.nombre}</strong>
                                                    <span className="badge bg-danger ms-2">Crítico</span>
                                                </td>
                                                <td>
                                                    <span className="badge bg-warning text-dark">
                                                        {prod.stock} unidades
                                                    </span>
                                                </td>
                                                <td>{prod.categoria.nombre}</td>
                                                <td>${prod.precio.toLocaleString('es-CL')}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    <div className="quick-actions">
                        <h3>Accesos Rápidos</h3>
                        <div className="row">
                            <div className="col-md-3 mb-3">
                                <Link to="/productos" className="action-card">
                                    <i className="bi bi-box-seam"></i>
                                    <p>Gestión de Productos</p>
                                </Link>
                            </div>
                            <div className="col-md-3 mb-3">
                                <Link to="/usuarios" className="action-card">
                                    <i className="bi bi-people"></i>
                                    <p>Gestión de Usuarios</p>
                                </Link>
                            </div>
                            <div className="col-md-3 mb-3">
                                <Link to="/crear-producto" className="action-card">
                                    <i className="bi bi-plus-circle"></i>
                                    <p>Crear Producto</p>
                                </Link>
                            </div>
                            <div className="col-md-3 mb-3">
                                <Link to="/crear-usuario" className="action-card">
                                    <i className="bi bi-person-plus"></i>
                                    <p>Crear Usuario</p>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>

                <Footer />
            </div>
        </>
    );
}