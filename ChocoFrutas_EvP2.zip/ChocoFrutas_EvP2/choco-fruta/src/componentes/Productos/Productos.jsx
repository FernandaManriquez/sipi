import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './Productos.css';

const API_BASE_URL = 'http://localhost:8080/api';

export function Productos() {
    const [productos, setProductos] = useState([]);
    const [busqueda, setBusqueda] = useState('');
    const [categoriaFiltro, setCategoriaFiltro] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const cargarProductos = async () => {
        try {
            setLoading(true);
            setError(null);
            
            console.log('🔄 Cargando productos...');
            const response = await fetch(`${API_BASE_URL}/productos`);
            
            console.log('📡 Status:', response.status);
            
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            
            const data = await response.json();
            console.log('📦 Datos recibidos:', data);
            console.log('📊 Total:', data.length);

           
            const productosNormalizados = (Array.isArray(data) ? data : []).map(p => ({
                ...p,  
                activo: p.activo === true || p.activo === 'true',
                categoria: p.categoria || { id: null, nombre: 'Sin categoría' }
            }));

            console.log('✅ Productos normalizados:', productosNormalizados);
            setProductos(productosNormalizados);
            setLoading(false);
            
        } catch (error) {
            console.error('❌ Error:', error);
            setError(error.message);
            setLoading(false);
        }
    };

    useEffect(() => {
        cargarProductos();
    }, []);

    const handleDesactivar = (id, nombre) => {
        if (window.confirm(`¿Estás seguro de desactivar el producto "${nombre}"?`)) {
            fetch(`${API_BASE_URL}/productos/${id}/desactivar`, {
                method: 'PATCH'
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error al desactivar el producto');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Producto desactivado:', data);
                    alert('Producto desactivado exitosamente');
                    cargarProductos();
                })
                .catch(error => {
                    console.error('Error al desactivar:', error);
                    alert('Error al desactivar el producto');
                });
        }
    };

    const productosFiltrados = productos.filter(p => {
        const matchBusqueda = p.nombre?.toLowerCase().includes(busqueda.toLowerCase());
        const matchCategoria = !categoriaFiltro || p.categoria?.nombre === categoriaFiltro;
        return matchBusqueda && matchCategoria;
    });

    const categorias = [...new Set(productos.map(p => p.categoria?.nombre).filter(Boolean))];

    if (loading) {
        return (
            <div className="container mi-tabla">
                <div className="text-center my-5">
                    <div className="spinner-border text-primary" role="status">
                        <span className="visually-hidden">Cargando...</span>
                    </div>
                    <p className="mt-3">Cargando productos...</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="container mi-tabla">
                <div className="alert alert-danger" role="alert">
                    <h4>❌ Error al cargar productos</h4>
                    <p>{error}</p>
                    <button className="btn btn-primary" onClick={cargarProductos}>
                        🔄 Reintentar
                    </button>
                </div>
            </div>
        );
    }

    return (
        <>
            <div className="container mi-tabla">
                <h3 style={{ marginBottom: '20px' }}>Inventario de Productos</h3>

                {/* 📊 Info de productos */}
                <div className="alert alert-info mb-3">
                    📦 Total de productos: <strong>{productos.length}</strong> | 
                    Mostrando: <strong>{productosFiltrados.length}</strong>
                </div>

                <div className="row mb-3">
                    <div className="col-md-4">
                        <div className="input-group">
                            <span className="input-group-text">
                                <i className="bi bi-search"></i>
                            </span>
                            <input
                                type="text"
                                className="form-control"
                                placeholder="Buscar por nombre..."
                                value={busqueda}
                                onChange={(e) => setBusqueda(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="col-md-4">
                        <select
                            className="form-select"
                            value={categoriaFiltro}
                            onChange={(e) => setCategoriaFiltro(e.target.value)}
                        >
                            <option value="">Todas las categorías</option>
                            {categorias.map(cat => (
                                <option key={cat} value={cat}>{cat}</option>
                            ))}
                        </select>
                    </div>
                    <div className="col-md-4 text-end">
                        <Link className="btn btn-success" to="/crear-producto">
                            <i className="bi bi-plus-circle"></i> Crear Producto
                        </Link>
                    </div>
                </div>

                <div className="row">
                    <div className="col-md">
                        <table className="table table-hover table-striped">
                            <thead className="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Descripción</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Categoría</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                {productosFiltrados.length === 0 ? (
                                    <tr>
                                        <td colSpan="8" className="text-center">
                                            {productos.length === 0 
                                                ? '⚠️ No hay productos en la base de datos. Ejecuta el script SQL.' 
                                                : '🔍 No se encontraron productos con ese filtro'}
                                        </td>
                                    </tr>
                                ) : (
                                    productosFiltrados.map((prod) => (
                                        <tr
                                            key={prod.id}
                                            style={{
                                                opacity: prod.activo ? 1 : 0.5,
                                                backgroundColor: prod.activo ? 'white' : '#f8f8f8'
                                            }}
                                        >
                                            <td>{prod.id}</td>
                                            <td>
                                                <strong>{prod.nombre}</strong>
                                                {prod.stock < 5 && prod.activo && (
                                                    <span className="badge bg-warning ms-2">
                                                        <i className="bi bi-exclamation-triangle"></i> Stock Bajo
                                                    </span>
                                                )}
                                            </td>
                                            <td>{prod.descripcion}</td>
                                            <td className="text-success fw-bold">
                                                ${prod.precio?.toLocaleString('es-CL') || '0'}
                                            </td>
                                            <td>
                                                <span className={`badge ${prod.stock < 5 ? 'bg-danger' : 'bg-primary'}`}>
                                                    {prod.stock} unidades
                                                </span>
                                            </td>
                                            <td>
                                                <span className="badge bg-info">
                                                    {prod.categoria?.nombre || 'Sin categoría'}
                                                </span>
                                            </td>
                                            <td>
                                                {prod.activo ? (
                                                    <span className="badge bg-success">Activo</span>
                                                ) : (
                                                    <span className="badge bg-secondary">Inactivo</span>
                                                )}
                                            </td>
                                            <td>
                                                {prod.activo ? (
                                                    <>
                                                        <Link
                                                            className="btn btn-sm btn-outline-primary me-2"
                                                            to={`/editar-producto/${prod.id}`}
                                                        >
                                                            <i className="bi bi-pencil"></i> Editar
                                                        </Link>
                                                        <button
                                                            className="btn btn-sm btn-outline-danger"
                                                            onClick={() => handleDesactivar(prod.id, prod.nombre)}
                                                        >
                                                            <i className="bi bi-trash"></i> Desactivar
                                                        </button>
                                                    </>
                                                ) : (
                                                    <button className="btn btn-sm btn-secondary" disabled>
                                                        Desactivado
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    );
}