import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '../../componentes/Navbar/Navbar';
import './EditarUsuario.css';

export function EditarUsuario() {
    const { id } = useParams();
    const navigate = useNavigate();
    const usuarioId = parseInt(id);

    const [usuario, setUsuario] = useState({
        nombre: '',
        email: '',
        rol: '',
        activo: true
    });
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(false);

    useEffect(() => {
        const cargarUsuario = async () => {
            try {
                setLoading(true);

                const response = await fetch(`http://localhost:8080/api/usuarios/${usuarioId}`);

                if (!response.ok) {
                    throw new Error('Error al cargar el usuario');
                }

                const data = await response.json();
                console.log('Usuario cargado:', data);

                setUsuario({
                    ...data,
                    activo: data.activo === true || data.activo === 'true'
                });

                setError(null);

            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        if (usuarioId) {
            cargarUsuario();
        }
    }, [usuarioId]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUsuario(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async () => {
        setSaving(true);
        setError(null);
        setSuccess(false);

        try {
            const datosActualizados = {
                id: usuario.id,
                nombre: usuario.nombre,
                email: usuario.email,
                rol: usuario.rol,
                activo: usuario.activo
            };

            console.log('Datos a enviar:', datosActualizados);

            const response = await fetch(`http://localhost:8080/api/usuarios/${usuarioId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(datosActualizados)
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Respuesta del servidor:', errorText);
                throw new Error('Error al actualizar el usuario');
            }

            const usuarioActualizado = await response.json();
            console.log('Usuario actualizado exitosamente:', usuarioActualizado);
            setSuccess(true);

            setTimeout(() => {
                navigate('/usuarios');
            }, 1500);

        } catch (err) {
            console.error('Error completo:', err);
            setError(err.message);
        } finally {
            setSaving(false);
        }
    };

    const handleVolver = () => {
        navigate('/usuarios');
    };

    if (loading) {
        return (
            <>
                <Navbar />
                <div className="container mt-5">
                    <div className="text-center">
                        <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
                            <span className="visually-hidden">Cargando...</span>
                        </div>
                        <p className="mt-3 text-muted">Cargando usuario...</p>
                    </div>
                </div>
            </>
        );
    }

    return (
        <>
            <Navbar />

            <div className="container mt-3" style={{ maxWidth: '600px' }}>
                <div className="card">
                    <div className="card-header bg-primary text-white d-flex justify-content-between align-items-center py-2">
                        <h6 className="mb-0">Editar Usuario</h6>
                        <button
                            onClick={handleVolver}
                            type="button"
                            className="btn-close btn-close-white"
                            aria-label="Cerrar"
                        ></button>
                    </div>

                    <div className="card-body p-3">
                        {error && (
                            <div className="alert alert-danger py-2 mb-2 small">
                                {error}
                            </div>
                        )}

                        {success && (
                            <div className="alert alert-success py-2 mb-2 small">
                                Usuario actualizado exitosamente
                            </div>
                        )}

                        <div className="mb-2">
                            <label className="form-label small mb-1">Nombre</label>
                            <input
                                type="text"
                                name="nombre"
                                value={usuario.nombre}
                                onChange={handleChange}
                                className="form-control form-control-sm"
                            />
                        </div>

                        <div className="mb-2">
                            <label className="form-label small mb-1">Email</label>
                            <input
                                type="email"
                                value={usuario.email}
                                disabled
                                className="form-control form-control-sm bg-light"
                            />
                        </div>

                        <div className="mb-3">
                            <label className="form-label small mb-1">Rol</label>
                            <select
                                name="rol"
                                value={usuario.rol}
                                onChange={handleChange}
                                className="form-select form-control-sm">
                                <option value="cliente">Cliente</option>
                                <option value="vendedor">Vendedor</option>
                                <option value="super-admin">Super Admin</option>
                            </select>
                        </div>

                        <div className="d-flex gap-2 pt-2 border-top">
                            <button
                                onClick={handleVolver}
                                type="button"
                                className="btn btn-sm btn-secondary">
                                Cancelar
                            </button>
                            <button
                                onClick={handleSubmit}
                                disabled={saving}
                                type="button"
                                className="btn btn-sm btn-primary flex-grow-1">
                                {saving ? 'Guardando...' : 'Guardar Cambios'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}