import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '../Navbar/Navbar';
import './EditarProd.css';

const API_BASE_URL = 'http://localhost:8080/api';

export function EditarProducto() {
    const { id } = useParams();
    const navigate = useNavigate();
    const productoId = parseInt(id);

    const [producto, setProducto] = useState({
        nombre: '',
        descripcion: '',
        precio: '',
        stock: '',
        categoria: {
            id: '',
            nombre: ''
        },
        imagen: ''
    });

    const [categorias, setCategorias] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(false);

    useEffect(() => {
        const cargarDatos = async () => {
            try {
                setLoading(true);

                const respProducto = await fetch(`${API_BASE_URL}/productos/${productoId}`);
                if (!respProducto.ok) {
                    throw new Error('Error al cargar el producto');
                }
                const dataProducto = await respProducto.json();

                
                setProducto({
                    ...dataProducto,  
                    descripcion: dataProducto.descripcion || ''
                });

                const respCategorias = await fetch(`${API_BASE_URL}/categorias`);
                if (!respCategorias.ok) {
                    throw new Error('Error al cargar categorías');
                }
                const dataCategorias = await respCategorias.json();

                setCategorias(dataCategorias);
                setError(null);

            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        if (productoId) {
            cargarDatos();
        }
    }, [productoId]);

    const handleChange = (e) => {
        const { name, value } = e.target;

        if (name === 'categoriaId') {
            const categoriaSeleccionada = categorias.find(c => c.id === parseInt(value));
            
            setProducto(prev => ({
                ...prev,  
                categoria: categoriaSeleccionada || { id: value, nombre: '' }
            }));
        } else {
           
            setProducto(prev => ({
                ...prev,  
                [name]: value
            }));
        }
    };

    const handleSubmit = async () => {
        setSaving(true);
        setError(null);
        setSuccess(false);

        try {
            const datosActualizados = {
                id: producto.id,
                nombre: producto.nombre,
                descripcion: producto.descripcion,
                precio: parseInt(producto.precio) || 0,
                stock: parseInt(producto.stock) || 0,
                imagen: producto.imagen
            };

            if (producto.categoria && producto.categoria.id) {
                datosActualizados.categoria = {
                    id: producto.categoria.id,
                    nombre: producto.categoria.nombre
                };
            }

            const response = await fetch(`${API_BASE_URL}/productos/${productoId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(datosActualizados)
            });

            if (!response.ok) {
                throw new Error('Error al actualizar el producto');
            }

            setSuccess(true);

            setTimeout(() => {
                navigate('/productos');
            }, 1500);

        } catch (err) {
            setError(err.message);
        } finally {
            setSaving(false);
        }
    };

    const handleVolver = () => {
        navigate('/productos');
    };

    if (loading) {
        return (
            <>
                <Navbar />
                <div className="container mt-5">
                    <div className="text-center">
                        <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
                            <span className="visually-hidden">Cargando...</span>
                        </div>
                        <p className="mt-3 text-muted">Cargando producto...</p>
                    </div>
                </div>
            </>
        );
    }

    return (
        <>
            <Navbar />

            <div className="container mt-4" style={{ maxWidth: '700px' }}>
                <div className="card">
                    <div className="card-header d-flex justify-content-between align-items-center">
                        <h5 className="mb-0">
                            <i className="bi bi-pencil-square"></i> Editar Producto
                        </h5>
                        <button
                            onClick={handleVolver}
                            type="button"
                            className="btn-close"
                            aria-label="Cerrar"
                        ></button>
                    </div>

                    <div className="card-body">
                        {error && (
                            <div className="alert alert-danger">
                                <i className="bi bi-exclamation-triangle-fill"></i> {error}
                            </div>
                        )}

                        {success && (
                            <div className="alert alert-success">
                                <i className="bi bi-check-circle-fill"></i> Producto actualizado exitosamente
                            </div>
                        )}

                        <div className="mb-3">
                            <label className="form-label fw-bold">Nombre del Producto</label>
                            <input
                                type="text"
                                value={producto.nombre}
                                disabled
                                className="form-control bg-light"
                            />
                        </div>

                        <div className="mb-3">
                            <label className="form-label fw-bold">Descripción</label>
                            <textarea
                                name="descripcion"
                                value={producto.descripcion}
                                onChange={handleChange}
                                rows={3}
                                className="form-control"
                                placeholder="Descripción del producto"
                            />
                        </div>

                        <div className="row g-3 mb-3">
                            <div className="col-md-6">
                                <label className="form-label fw-bold">Precio</label>
                                <div className="input-group">
                                    <span className="input-group-text">$</span>
                                    <input
                                        type="number"
                                        name="precio"
                                        value={producto.precio}
                                        onChange={handleChange}
                                        min="0"
                                        className="form-control"
                                        placeholder="0"
                                    />
                                </div>
                            </div>

                            <div className="col-md-6">
                                <label className="form-label fw-bold">Stock</label>
                                <input
                                    type="number"
                                    name="stock"
                                    value={producto.stock}
                                    onChange={handleChange}
                                    min="0"
                                    className="form-control"
                                    placeholder="0"
                                />
                            </div>
                        </div>

                        <div className="mb-3">
                            <label className="form-label fw-bold">Categoría</label>
                            <input
                                type="text"
                                value={producto.categoria?.nombre || 'Sin categoría'}
                                disabled
                                className="form-control bg-light"
                            />
                        </div>

                        <div className="mb-3">
                            <label className="form-label fw-bold">Imagen</label>
                            <input
                                type="text"
                                name="imagen"
                                value={producto.imagen}
                                onChange={handleChange}
                                className="form-control"
                                placeholder="nombre-imagen.jpg"
                            />
                        </div>

                        <div className="d-flex gap-2 pt-3 border-top">
                            <button
                                onClick={handleVolver}
                                type="button"
                                className="btn btn-secondary">
                                <i className="bi bi-x-circle"></i> Cancelar
                            </button>
                            <button
                                onClick={handleSubmit}
                                disabled={saving}
                                type="button"
                                className="btn btn-primary flex-grow-1">
                                {saving ? (
                                    <>
                                        <span className="spinner-border spinner-border-sm me-2"></span>
                                        Guardando...
                                    </>
                                ) : (
                                    <>
                                        <i className="bi bi-save"></i> Guardar Cambios
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}