import { Link, useLocation, useNavigate } from 'react-router-dom';
import { obtenerUsuario, cerrarSesion, estaLogueado, esAdmin } from '../../utils/session';
import './Navbar.css';

export function Navbar() {
    const location = useLocation();
    const navigate = useNavigate();
    const usuario = obtenerUsuario();
    const logueado = estaLogueado();
    const esAdminOVendedor = esAdmin();

    const handleLogout = () => {
        if (window.confirm('¿Estás seguro de cerrar sesión?')) {
            cerrarSesion();
            navigate('/login');
        }
    };

    return (
        <nav className="navbar navbar-expand-lg navbar-light">
            <div className="container">
                <Link className="navbar-brand" to={logueado ? (esAdminOVendedor ? "/dashboard" : "/") : "/"}>
                    <img 
                        src="/img/Logo.png" 
                        alt="Choco&Frutas" 
                    />
                    Choco&Frutas
                </Link>
                
                <button 
                    className="navbar-toggler" 
                    type="button" 
                    data-bs-toggle="collapse" 
                    data-bs-target="#menuNav">
                    <span className="navbar-toggler-icon"></span>
                </button>
                
                <div className="collapse navbar-collapse" id="menuNav">
                    <ul className="navbar-nav ms-auto">
                        {logueado ? (
                            esAdminOVendedor ? (
                                <>
                                    <li className="nav-item">
                                        <Link 
                                            className={`nav-link ${location.pathname === '/dashboard' ? 'active' : ''}`}
                                            to="/dashboard">
                                            <i className="bi bi-speedometer2"></i> Dashboard
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link 
                                            className={`nav-link ${location.pathname === '/productos' ? 'active' : ''}`}
                                            to="/productos">
                                            <i className="bi bi-box-seam"></i> Productos
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link 
                                            className={`nav-link ${location.pathname === '/usuarios' ? 'active' : ''}`}
                                            to="/usuarios">
                                            <i className="bi bi-people"></i> Usuarios
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <span className="nav-link user-info">
                                            <i className="bi bi-person-circle"></i> {usuario?.nombre || 'Admin'}
                                        </span>
                                    </li>
                                    <li className="nav-item">
                                        <button onClick={handleLogout} className="nav-link btn-logout">
                                            <i className="bi bi-box-arrow-right"></i> Salir
                                        </button>
                                    </li>
                                </>
                            ) : (
                                <>
                                    <li className="nav-item">
                                        <Link 
                                            className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}
                                            to="/">
                                            <i className="bi bi-house"></i> Home
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link 
                                            className={`nav-link ${location.pathname === '/catalogo' ? 'active' : ''}`}
                                            to="/catalogo">
                                            <i className="bi bi-box-seam"></i> Catálogo
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link 
                                            className={`nav-link ${location.pathname === '/contacto' ? 'active' : ''}`}
                                            to="/contacto">
                                            <i className="bi bi-envelope"></i> Contacto
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <span className="nav-link user-info">
                                            <i className="bi bi-person-circle"></i> {usuario?.nombre || 'Usuario'}
                                        </span>
                                    </li>
                                    <li className="nav-item">
                                        <button onClick={handleLogout} className="nav-link btn-logout">
                                            <i className="bi bi-box-arrow-right"></i> Salir
                                        </button>
                                    </li>
                                </>
                            )
                        ) : (
                            <>
                                <li className="nav-item">
                                    <Link 
                                        className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}
                                        to="/">
                                        <i className="bi bi-house"></i> Home
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link 
                                        className={`nav-link ${location.pathname === '/catalogo' ? 'active' : ''}`}
                                        to="/catalogo">
                                        <i className="bi bi-box-seam"></i> Catálogo
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link 
                                        className={`nav-link ${location.pathname === '/contacto' ? 'active' : ''}`}
                                        to="/contacto">
                                        <i className="bi bi-envelope"></i> Contacto
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link 
                                        className={`nav-link ${location.pathname === '/login' ? 'active' : ''}`}
                                        to="/login">
                                        <i className="bi bi-box-arrow-in-right"></i> Login
                                    </Link>
                                </li>
                            </>
                        )}
                    </ul>
                </div>
            </div>
        </nav>
    );
}
